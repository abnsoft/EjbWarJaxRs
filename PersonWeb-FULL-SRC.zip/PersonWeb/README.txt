----------------------
-- EJB in WAR 
----------------------

1. created in Eclipse LUNA SP1, JBOSS TOOLS 
2. Optimized for WildFly 8.2, JDK 1.8

in this project are used :
- EJB in WAR 
- JAX-RS RESTeasy web services
- JSF, JQuery, JQuery-ui, Knockout.js


This example shows how to use EJB in WAR.

This project was builded with MAVEN (or Eclipse - as you wish).
Any way it should be imported into IDE as MAVEN Project, because it does not contain any IDE depended files.