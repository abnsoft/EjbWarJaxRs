/**
 * Copyright 2015. ABN Software. All Rights reserved.<br>
 * <br>
 * Homepage .... http://www.ABNsoft.info<br>
 * <br>
 * Project ..... PersonWeb<br>
 * <br>
 * Author ...... AnNik<br>
 * E-Mail ...... ABN.DEV@mail.ru<br>
 * Created ..... 15 марта 2015 г.<br>
 * <br>
 */
package test.ejb.person;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author annik
 *
 */
@ApplicationPath( "/rs" )
public class PersonApplication extends Application {

}
