/**
 * Copyright 2015. ABN Software. All Rights reserved.<br>
 * <br>
 * Homepage .... http://www.ABNsoft.info<br>
 * <br>
 * Project ..... PersonEjb<br>
 * <br>
 * Author ...... AnNik<br>
 * E-Mail ...... ABN.DEV@mail.ru<br>
 * Created ..... 14 марта 2015 г.<br>
 * <br>
 */
/**
 * Project`d Entities.
 * 
 * @author annik
 *
 */
package test.ejb.person.entity;